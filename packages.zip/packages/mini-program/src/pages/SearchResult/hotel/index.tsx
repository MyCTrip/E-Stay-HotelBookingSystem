import { useEffect, useState } from 'react'
import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useRouter } from '@tarojs/taro'
import { useHotelStore } from '@estay/shared'
import type { Hotel } from '@estay/shared'

import MainLayout from '../../../layouts/MainLayout'
import VirtualHotelList from '../../../components/VirtualHotelList'
import styles from './index.module.scss'

export default function SearchResultHotel() {
  const router = useRouter()
  
  // --- 全局状态 ---
  const ui = useHotelStore(state => state.ui)
  const searchParams = useHotelStore(state => state.searchParams)
  const setSearchParams = useHotelStore(state => state.setSearchParams)
  const fetchHotels = useHotelStore(state => state.fetchHotels)
  const fetchMoreHotels = useHotelStore(state => state.fetchMoreHotels)

  // --- 本地状态 ---
  const [activeFilter, setActiveFilter] = useState<string>('welcome')
  const [activeTag, setActiveTag] = useState<string>('天安门广场')

  // ==========================================
  // 修复英文城市名：强制做一层转换（实际开发中可写个工具函数映射城市码）
  // ==========================================
  const displayCity = searchParams.city === 'Beijing' || router.params.city === 'Beijing' 
    ? '北京' 
    : (searchParams.city || '北京');

  // ==========================================
  // 📦 高保真 Mock 数据
  // ==========================================
  const mockHotels: Hotel[] = [
    {
      _id: 'm1',
      baseInfo: {
        nameCn: '北京王府井文华东方酒店',
        city: '北京',
        star: 5,
        images: ['https://images.unsplash.com/photo-1551882547-ff40c0d5e9af?auto=format&fit=crop&w=400&q=80'],
        address: '王府井大街269号', phone: '', description: '', facilities: [], policies: []
      },
      displayInfo: {
        rating: 4.9, reviewCount: 3200, lowestPrice: 2888, originalPrice: 3500,
        distanceText: '王府井/故宫 · 距您直线 100m',
        tags: ['紫禁城景观', '米其林餐厅', '室内泳池', '极速确认']
      }
    },
    {
      _id: 'm2',
      baseInfo: {
        nameCn: '全季酒店 (北京天安门广场店)',
        city: '北京',
        star: 3,
        images: ['https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=400&q=80'],
        address: '前门大街1号', phone: '', description: '', facilities: [], policies: []
      },
      displayInfo: {
        rating: 4.6, reviewCount: 1560, lowestPrice: 450,
        distanceText: '前门/天安门广场 · 距您直线 800m',
        tags: ['近地铁', '免费停车', '极速退房']
      }
    },
    {
      _id: 'm3',
      baseInfo: {
        nameCn: '7天连锁酒店 (北京国贸CBD店)',
        city: '北京',
        star: 2,
        images: ['https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=400&q=80'],
        address: '建国路88号', phone: '', description: '', facilities: [], policies: []
      },
      displayInfo: {
        rating: 4.2, reviewCount: 890, lowestPrice: 199, originalPrice: 259,
        distanceText: '国贸地区 · 距您直线 4.5km',
        tags: ['特卖', '含双早']
      }
    }
  ] as unknown as Hotel[]

  // --- 初始化加载 ---
  useEffect(() => {
    // 使用提取出来的 displayCity
    setSearchParams({ city: displayCity, page: 1 })
    fetchHotels({ city: displayCity, page: 1 })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // --- 交互逻辑 ---
  const goToDetail = (id: string) => Taro.navigateTo({ url: `/pages/HotelDetail/hotel/index?id=${id}` })

  return (
    <MainLayout>
      <View className={styles.pageContainer}>
        
        {/* ================= 1. 顶部核心条件筛选头 ================= */}
        <View className={styles.coreHeader}>
          <View className={styles.searchCapsule}>
            {/* 城市选择：使用 displayCity */}
            <View className={styles.cityBlock} onClick={() => console.log('切换城市')}>
              <Text className={styles.cityText}>{displayCity}</Text>
              <Text className={styles.arrowDown}>▾</Text>
            </View>

            {/* 日期与间夜数 */}
            <View className={styles.dateBlock} onClick={() => console.log('修改日期')}>
              <View className={styles.dateCol}>
                <Text className={styles.dateValue}>02-17</Text>
                <Text className={styles.dateValue}>02-18</Text>
              </View>
              <View className={styles.nightCol}>
                <Text className={styles.nightText}>1间</Text>
                <Text className={styles.nightText}>1人</Text>
              </View>
            </View>

            {/* 搜索词 */}
            <View className={styles.searchInput} onClick={() => console.log('进入文字搜索')}>
              <Text className={styles.searchIcon}>🔍</Text>
              <Text className={styles.placeholder}>位置/品牌/酒店</Text>
            </View>

            {/* 地图按钮 */}
            <View className={styles.mapBtn}>
              <Text className={styles.mapIcon}>🗺️</Text>
              <Text className={styles.mapText}>地图</Text>
            </View>
          </View>
        </View>

        {/* ================= 2. 详细筛选区域 ================= */}
        <View className={styles.filterSection}>
          <View className={styles.mainFilters}>
            {[
              { id: 'welcome', label: '欢迎度排序' },
              { id: 'distance', label: '位置距离' },
              { id: 'price', label: '价格/星级' },
              { id: 'filter', label: '筛选' }
            ].map(item => (
              <View 
                key={item.id} 
                className={`${styles.filterItem} ${activeFilter === item.id ? styles.activeFilter : ''}`}
                onClick={() => setActiveFilter(item.id)}
              >
                <Text>{item.label}</Text>
                <Text className={styles.arrowIcon}>▾</Text>
              </View>
            ))}
          </View>

          <ScrollView scrollX className={styles.tagScroll} showScrollbar={false}>
            <View className={styles.tagWrapper}>
              {['天安门广场', '双床房', '含早餐', '亲子酒店', '返10倍积分', '免费取消'].map(tag => (
                <View 
                  key={tag} 
                  className={`${styles.quickTag} ${activeTag === tag ? styles.activeTag : ''}`}
                  onClick={() => setActiveTag(tag)}
                >
                  <Text>{tag}</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* ================= 3. 酒店列表区域 ================= */}
        <View className={styles.listSection}>
          <VirtualHotelList 
            hotels={mockHotels} 
            hasMore={true}      
            moreLoading={ui.moreLoading} 
            onLoadMore={() => fetchMoreHotels()}
            onHotelClick={goToDetail}
          />
        </View>

      </View>
    </MainLayout>
  )
}